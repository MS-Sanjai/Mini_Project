package com.Dynamic.CardViewProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CardViewProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CardViewProjectApplication.class, args);
	}

}
