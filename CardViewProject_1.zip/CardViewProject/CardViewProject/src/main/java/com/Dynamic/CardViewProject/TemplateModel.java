package com.Dynamic.CardViewProject;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;

@Entity
@Table(name = "TemplateModel")
public class TemplateModel {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int UserId;
	
	
	private String name;
	private String UserAddress;
    private String Userphone;
    private String Usermail;
   
    private String Userprofileimg;
    private LocalDateTime dateupdated;
	public TemplateModel() {
		super();
	}
	public TemplateModel(int userId, String name, String userAddress, String userphone, String usermail,
			String userprofileimg, LocalDateTime dateupdated) {
		super();
		UserId = userId;
		this.name = name;
		UserAddress = userAddress;
		Userphone = userphone;
		Usermail = usermail;
		Userprofileimg = userprofileimg;
		this.dateupdated = dateupdated;
	}
	public int getUserId() {
		return UserId;
	}
	public void setUserId(int userId) {
		UserId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUserAddress() {
		return UserAddress;
	}
	public void setUserAddress(String userAddress) {
		UserAddress = userAddress;
	}
	public String getUserphone() {
		return Userphone;
	}
	public void setUserphone(String userphone) {
		Userphone = userphone;
	}
	public String getUsermail() {
		return Usermail;
	}
	public void setUsermail(String usermail) {
		Usermail = usermail;
	}
	public String getUserprofileimg() {
		return Userprofileimg;
	}
	public void setUserprofileimg(String userprofileimg) {
		Userprofileimg = userprofileimg;
	}
	public LocalDateTime getDateupdated() {
		return dateupdated;
	}
	public void setDateupdated(LocalDateTime dateupdated) {
		this.dateupdated = dateupdated;
	}
    
    

}
