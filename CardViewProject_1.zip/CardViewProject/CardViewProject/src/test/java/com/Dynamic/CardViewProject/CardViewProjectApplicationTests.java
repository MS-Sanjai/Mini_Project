package com.Dynamic.CardViewProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CardViewProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
